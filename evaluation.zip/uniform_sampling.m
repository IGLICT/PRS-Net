function [samples] = uniform_sampling(v,f, numSamples)
% Perform uniform sampling of a mesh, with the numSamples samples
% samples: a matrix of dimension 3 x numSamples
f=f';
v=v';
t = sort(rand(1, numSamples));
faceAreas = tri_mesh_face_area(v,f);
numFaces = length(faceAreas);
for i = 2:numFaces
    faceAreas(i) = faceAreas(i-1) + faceAreas(i);
end
samples = zeros(3, numSamples);

paras = rand(2, numSamples);

faceId = 1;
for sId = 1:numSamples
    while t(sId) > faceAreas(faceId)
        faceId = faceId + 1;
    end
    faceId = min(faceId, numFaces);
    p1 = v(:, f(1, faceId));
    p2 = v(:, f(2, faceId));
    p3 = v(:, f(3, faceId));
    
    r1 = paras(1, sId);
    r2 = paras(2, sId);
    t1 = 1-sqrt(r1);
    t2 = sqrt(r1)*(1-r2);
    t3 = sqrt(r1)*r2;
    samples(:, sId) = t1*p1 + t2*p2 + t3*p3;
end

end

function [faceAreas] = tri_mesh_face_area(v,f)
%
p1 = v(:, f(1,:));
p2 = v(:, f(2,:));
p3 = v(:, f(3,:));

e12 = p1 - p2;
e23 = p2 - p3;
e31 = p3 - p1;

a2 = sum(e12.*e12);
b2 = sum(e23.*e23);
c2 = sum(e31.*e31);

areas = 2*(a2.*(b2+c2)+b2.*c2)-a2.*a2-b2.*b2-c2.*c2;
areas = sqrt(max(0, areas))/4;
faceAreas = areas/sum(areas);
end