fid = fopen('1000.txt');
data = textscan(fid,'%s %s');
fclose(fid);
models = data{1};
load('gt_planes.mat');
sde = zeros(1000,3);
for i=1:length(models)
    i
    [vertices,faces] = readobjfromfile(['./objs/',models{i},'.obj']);
    faces = faces + 1;
    sample = uniform_sampling(vertices,faces,1000);
    for j=1:3
        if ~isempty(gt_planes{i,j})
        [sde(i,j),~]=calplaneloss(gt_planes{i,j},vertices,faces,sample');
        end
    end
end
error = sum(sde(:)) / length(find(sde(:)>0));