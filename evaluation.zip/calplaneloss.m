function [loss,d]=calplaneloss(plane,vertices,faces,points)
    if size(points,2) ~= 4 
        points(:,4)=1;
    end
    lam = points*plane';
    planepoints = points - 2*plane.*lam;
    [d,~,~]=point_mesh_squared_distance(planepoints(:,1:3),vertices,double(faces));
    loss=sum(d) / size(points,1);
end